var struct_u_t_i_l___s_e_q___priority__t =
[
    [ "priority", "struct_u_t_i_l___s_e_q___priority__t.html#a59563315cdb7b76c8a482160851cac3f", null ],
    [ "round_robin", "struct_u_t_i_l___s_e_q___priority__t.html#a10895a689ca10b69554ba4a822329f54", null ]
];